# Angular---7-Crud-using-LocalStorage
This is CRUD application built using Angular-7 and localstorage

Clone or download the repo

1. Run the command: npm install
This will install all dependency required for project

2. Run the command: ng serve
This will run the project on browser url : http://localhost:4200


If any issues Please raise.
